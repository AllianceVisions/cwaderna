<?php

return [
    'site_title' => 'CWADERNA',
];