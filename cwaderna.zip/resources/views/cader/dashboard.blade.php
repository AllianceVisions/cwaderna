@extends('layouts.cader')
@section('content')
<div class="content">
    #Cader
</div>
@endsection
@section('scripts')
@parent
{{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>{!! $chart1->renderJs() !!}{!! $chart2->renderJs() !!} --}}

@endsection